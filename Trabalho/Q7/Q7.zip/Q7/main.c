#include <stdio.h>
#include "Q7.h"

int main(){
    Lista *l;
    duas_lista(l);

    return 0;
}